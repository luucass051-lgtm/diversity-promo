// Configure o BACKEND_URL para o IP da sua máquina / servidor onde o backend rodará.
// Exemplo: 'http://192.168.0.10:3000' ou 'http://10.0.2.2:3000' (em emulador Android).
export default {
  BACKEND_URL: 'http://127.0.0.1:3000'
};
